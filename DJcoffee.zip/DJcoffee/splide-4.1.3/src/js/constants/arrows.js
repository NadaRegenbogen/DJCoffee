"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ARROW_DOWN = exports.ARROW_UP = exports.ARROW_RIGHT = exports.ARROW_LEFT = void 0;
const ARROW = 'Arrow';
exports.ARROW_LEFT = `${ARROW}Left`;
exports.ARROW_RIGHT = `${ARROW}Right`;
exports.ARROW_UP = `${ARROW}Up`;
exports.ARROW_DOWN = `${ARROW}Down`;
//# sourceMappingURL=arrows.js.map