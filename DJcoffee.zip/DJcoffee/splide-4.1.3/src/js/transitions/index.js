"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Slide = exports.Fade = void 0;
var Fade_1 = require("./Fade/Fade");
Object.defineProperty(exports, "Fade", { enumerable: true, get: function () { return Fade_1.Fade; } });
var Slide_1 = require("./Slide/Slide");
Object.defineProperty(exports, "Slide", { enumerable: true, get: function () { return Slide_1.Slide; } });
//# sourceMappingURL=index.js.map