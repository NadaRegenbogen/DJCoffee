"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.find = exports.slice = void 0;
var slice_1 = require("./slice/slice");
Object.defineProperty(exports, "slice", { enumerable: true, get: function () { return slice_1.slice; } });
var find_1 = require("./find/find");
Object.defineProperty(exports, "find", { enumerable: true, get: function () { return find_1.find; } });
//# sourceMappingURL=index.js.map