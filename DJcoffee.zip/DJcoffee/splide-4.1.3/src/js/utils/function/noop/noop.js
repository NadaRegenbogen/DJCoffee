"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.noop = void 0;
/**
 * No operation.
 */
const noop = () => { }; // eslint-disable-line no-empty-function, @typescript-eslint/no-empty-function
exports.noop = noop;
//# sourceMappingURL=noop.js.map