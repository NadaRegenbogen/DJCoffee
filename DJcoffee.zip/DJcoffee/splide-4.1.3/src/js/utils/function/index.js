"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.raf = exports.noop = exports.nextTick = exports.apply = void 0;
var apply_1 = require("./apply/apply");
Object.defineProperty(exports, "apply", { enumerable: true, get: function () { return apply_1.apply; } });
var nextTick_1 = require("./nextTick/nextTick");
Object.defineProperty(exports, "nextTick", { enumerable: true, get: function () { return nextTick_1.nextTick; } });
var noop_1 = require("./noop/noop");
Object.defineProperty(exports, "noop", { enumerable: true, get: function () { return noop_1.noop; } });
var raf_1 = require("./raf/raf");
Object.defineProperty(exports, "raf", { enumerable: true, get: function () { return raf_1.raf; } });
//# sourceMappingURL=index.js.map