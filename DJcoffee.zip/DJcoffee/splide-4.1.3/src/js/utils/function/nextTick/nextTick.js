"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nextTick = void 0;
/**
 * Invokes the callback on the next tick.
 *
 * @param callback - A callback function.
 */
exports.nextTick = setTimeout;
//# sourceMappingURL=nextTick.js.map