"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.error = exports.assert = void 0;
var assert_1 = require("./assert/assert");
Object.defineProperty(exports, "assert", { enumerable: true, get: function () { return assert_1.assert; } });
var error_1 = require("./error/error");
Object.defineProperty(exports, "error", { enumerable: true, get: function () { return error_1.error; } });
//# sourceMappingURL=index.js.map