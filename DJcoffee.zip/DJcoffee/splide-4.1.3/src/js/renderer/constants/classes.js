"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CLASS_RENDERED = void 0;
exports.CLASS_RENDERED = 'is-rendered';
//# sourceMappingURL=classes.js.map