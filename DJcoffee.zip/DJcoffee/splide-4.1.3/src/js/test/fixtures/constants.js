"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SLIDER_WIDTH = exports.URL = void 0;
/**
 * The dummy url.
 */
exports.URL = 'https://test.com';
/**
 * The root and track width.
 */
exports.SLIDER_WIDTH = 1280;
//# sourceMappingURL=constants.js.map